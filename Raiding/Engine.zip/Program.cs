﻿using Raiding.Engine;

Engine engine = new Engine();
engine.Run();